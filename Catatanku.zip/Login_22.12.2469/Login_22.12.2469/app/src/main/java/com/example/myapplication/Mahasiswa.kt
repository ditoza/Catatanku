package com.example.myapplication

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Mahasiswa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mahasiswa)

        val rv_mahasiswa:RecyclerView = findViewById(R.id.rv_mahasiswa)
        val id:MutableList<String> = mutableListOf()
        val nama:MutableList<String> = mutableListOf();

        val nim:MutableList<String> = mutableListOf();

        val foto:MutableList<Int> = mutableListOf()


        //panggil database kampus
        val dbkampus:SQLiteDatabase = openOrCreateDatabase("kampus", MODE_PRIVATE, null)

        //gali data dari tabel mahasiswa
        val gali_mahasisawa = dbkampus.rawQuery("SELECT * FROM mahasiswa", null)
        while (gali_mahasisawa.moveToNext())
        {
            id.add(gali_mahasisawa.getString(0))
            nim.add(gali_mahasisawa.getString(1))
            nama.add(gali_mahasisawa.getString(2))
            foto.add(R.drawable.noimage)
        }
        val mi = Mahasiswa_Item(this, id, nama, nim, foto)

        rv_mahasiswa.adapter = mi
        rv_mahasiswa.layoutManager = GridLayoutManager(this, 2)

        val btn_tambah:Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah:Intent=Intent(this, Mahasiswa_tambah::class.java)
            startActivity(pindah)
        }
    }
}