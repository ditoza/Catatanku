package com.example.myapplication

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Register : AppCompatActivity() {

    private lateinit var edtEmail: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var dbKampus: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        dbKampus = openOrCreateDatabase("kampus", MODE_PRIVATE, null)
        dbKampus.execSQL("CREATE TABLE IF NOT EXISTS user (email_user TEXT, password_user TEXT)")

        edtEmail = findViewById(R.id.edt_email)
        edtPassword = findViewById(R.id.edt_password)
        btnRegister = findViewById(R.id.btn_register)

        btnRegister.setOnClickListener {
            val email = edtEmail.text.toString()
            val password = edtPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                val query = dbKampus.rawQuery(
                    "SELECT * FROM user WHERE email_user='$email' AND password_user='$password'",
                    null
                )
                val cek = query.moveToNext()

                if (!cek) {
                    dbKampus.execSQL("INSERT INTO user (email_user, password_user) VALUES ('$email', '$password')")
                    // Data berhasil ditambahkan
                    // Tambahkan logika redirect ke halaman login atau ke tindakan yang sesuai di sini
                    // Contoh: Menggunakan Intent untuk kembali ke halaman login
                    val intent = Intent(this, Login::class.java)
                    startActivity(intent)
                    finish() // Optional, untuk menutup activity saat ini jika tidak ingin kembali ke RegisterActivity lagi
                } else {
                    // Email dan password telah digunakan
                    Toast.makeText(this, "Email atau password telah digunakan", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Handle jika email atau password kosong
                Toast.makeText(this, "Email atau password tidak boleh kosong", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
