package com.example.myapplication

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText

class Mahasiswa_tambah : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mahasiswa_tambah)
        val edt_nim:EditText = findViewById(R.id.edt_nim)
        val edt_nama:EditText = findViewById(R.id.edt_nama)
        val btn_simpan:Button = findViewById(R.id.btn_simpan)

        btn_simpan.setOnClickListener {
            val isi_nim:String = edt_nim.text.toString()
            val isi_nama:String = edt_nama.text.toString()

            val dbkampus:SQLiteDatabase = openOrCreateDatabase("Kampus", MODE_PRIVATE , null)
            val eksekutor = dbkampus.rawQuery("INSERT INTO mahasiswa (nim_mahasiswa,nama_mahasiswa) VALUES($isi_nim,$isi_nama)", null)
            eksekutor.moveToNext()

            val pindah:Intent = Intent(this, Mahasiswa::class.java)
            startActivity(pindah)
        }
    }
}