package com.example.myapplication

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Mahasiswa_hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mahasiswa_hapus)
        val id_mahasiswa_terpilih:String = intent.getStringExtra("id_mahasiswa_terpilih").toString()

        //panggil database kampus
        val dbkampus: SQLiteDatabase = openOrCreateDatabase("kampus", MODE_PRIVATE, null)

        //gali data dari tabel mahasiswa
        val query = dbkampus.rawQuery("DELETE FROM mahasiswa WHERE id_mahasiswa='$id_mahasiswa_terpilih'", null)
        query.moveToNext()

        val pindah:Intent = Intent(this, Mahasiswa::class.java)
        startActivity(pindah)
    }
}